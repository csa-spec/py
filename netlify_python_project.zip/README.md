# Python Website for Netlify

This sample uses Python to generate a static HTML website during Netlify's build process.

## Files
- `build_site.py` generates the website HTML.
- `netlify.toml` configures the build command and publish directory.

## Deploy
1. Upload `build_site.py` and `netlify.toml` to the root of a GitHub repository.
2. In Netlify, choose **Add new project** → **Import an existing project**.
3. Choose GitHub and select the repository.
4. Confirm build command: `python3 build_site.py`.
5. Confirm publish directory: `site`.
6. Deploy.

This runs Python during the build to generate static files; it does not run a persistent Python web server after deployment.
